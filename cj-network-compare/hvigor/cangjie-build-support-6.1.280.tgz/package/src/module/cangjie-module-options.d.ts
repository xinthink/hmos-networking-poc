import { CangjieOpt } from '@ohos/hvigor-ohos-plugin/src/options/build/build-opt';
/**
 * manage cangjie options config
 *
 * @since 2025/7/16
 */
export declare class CangjieModuleOptions {
    private readonly _path;
    private readonly _abiFilters;
    private readonly _strictCheckDependencies;
    private readonly _arguments;
    private readonly _flattenLibs;
    private readonly _collectSDKLibs?;
    constructor(cangjieOpt?: CangjieOpt);
    get path(): string;
    get abiFilters(): string[];
    get strictCheckDependencies(): boolean;
    get arguments(): string[];
    get flattenLibs(): boolean;
    get collectSDKLibs(): boolean | undefined;
}
