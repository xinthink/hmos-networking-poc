/// <reference types="node" />
import { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
/**
 * cangjie dependent dynamic library collection
 *
 * @since 2024/1/6
 */
export declare class CangjieDependency {
    private _log;
    private includedModules;
    private existed;
    private _srcFilterHarPaths;
    private _binFilterHarPaths;
    private _packageName;
    private readonly abi;
    private readonly dependsEnv;
    private readonly targetTaskService;
    private dependenciesMap;
    private demandPackages;
    constructor(abi: string, dependsEnv: NodeJS.ProcessEnv, targetTaskService: TargetTaskService);
    set binFilterHarPaths(value: string[]);
    set srcFilterHarPaths(value: string[]);
    set packageName(value: string);
    getTargetRequires(moduleData: any, workspacePath: string, excludeFiles: string[]): void;
    getPackageRequires(moduleData: any, workspacePath: string, excludeFiles: string[]): void;
    getForeignCRequires(moduleData: any, workspacePath: string): void;
    getDependencies(moduleData: any, workspacePath: string, excludeFiles: string[]): void;
    doFindAllDependencies(workspacePathUriParam: string, excludeFiles: string[]): void;
    getPathByLockFile(workspacePath: string, moduleName: string): string;
    doCopyCompileLibs(folderPath: string, parentFolder: string, isFilter: boolean, destPath: string, isHar: boolean): Promise<void>;
    doCopyDependencies(buildOutputDir: string, isHarModule: boolean): Promise<void>;
    doCopyMacroCjoForBinHar(folderPath: string, destPath: string): Promise<void>;
    private copyLibFiles;
    private addDependencies;
    private getRequires;
    private getPackageOptions;
    private getPathOptions;
    private initDemandSrcPackages;
}
