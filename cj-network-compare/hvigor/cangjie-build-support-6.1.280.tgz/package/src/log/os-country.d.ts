export declare enum countryEnum {
    CN = "cn",
    EN = "en"
}
/**
 * 获取系统语言
 */
export declare function getOsLanguage(): countryEnum;
