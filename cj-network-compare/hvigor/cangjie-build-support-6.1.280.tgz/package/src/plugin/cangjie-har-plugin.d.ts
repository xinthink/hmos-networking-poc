/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { HarPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/har-plugin';
import { BaseCangjiePlugin } from './base-cangjie-plugin';
/**
 * cangjie har plugin
 *
 * @since 2024/1/6
 */
export declare class CangjieHarPlugin extends BaseCangjiePlugin {
    private harPlugin;
    constructor(harPlugin: HarPlugin);
    initCangjieTasks(): Promise<void>;
}
