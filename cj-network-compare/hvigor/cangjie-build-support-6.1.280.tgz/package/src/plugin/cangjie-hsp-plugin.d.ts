/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { HspPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/hsp-plugin';
import { BaseCangjiePlugin } from './base-cangjie-plugin';
/**
 * cangjie hsp plugin
 *
 * @since 2024/1/6
 */
export declare class CangjieHspPlugin extends BaseCangjiePlugin {
    private hspPlugin;
    constructor(hspPlugin: HspPlugin);
    initCangjieTasks(): Promise<void>;
}
