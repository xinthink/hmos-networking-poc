/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import { type Module, type Project } from '@ohos/hvigor';
import type { HapPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/hap-plugin';
import type { HarPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/har-plugin';
import type { HspPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/hsp-plugin';
import type { AppPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/app-plugin';
import { AbstractHapModulePlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/common/abstract-hap-module-plugin';
import { AbstractHarModulePlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/common/abstract-har-module-plugin';
export declare const ideaConfigPath: string;
/**
 * register cangjie app task
 */
export declare function registerAppTask(project: Project, appPlugin: AppPlugin): AppPlugin;
/**
 * register cangjie hap task
 */
export declare function registerHapTask(module: Module, abstractHapPlugin: AbstractHapModulePlugin): HapPlugin;
/**
 * register cangjie har task
 */
export declare function registerHarTask(module: Module, abstractHarPlugin: AbstractHarModulePlugin): HarPlugin;
/**
 * register cangjie hsp task
 */
export declare function registerHspTask(module: Module, hspPlugin: HspPlugin): HspPlugin;
/**
 * app task
 */
export declare function createAppTask(project: Project): AppPlugin;
/**
 * hap task
 */
export declare function createHapTask(module: Module): HapPlugin;
/**
 * har task
 */
export declare function createHarTask(module: Module): HarPlugin;
/**
 * hsp task
 */
export declare function createHspTask(module: Module): HspPlugin;
/**
 * replace schema
 */
export declare function handleSchema(): void;
