/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import { OhosLogger } from '@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger';
export declare enum AbiEnum {
    ARM64_V8A = "arm64-v8a",
    X86_64 = "x86_64"
}
export declare enum AbiTargetEnum {
    ARM64_V8A = "aarch64-linux-ohos",
    X86_64 = "x86_64-linux-ohos"
}
export declare function getTargetByAbi(abi: string): AbiTargetEnum;
export declare function reportAbiError(logger: OhosLogger, abi: string): void;
export declare function isValueInAbiEnum(value: string, enumObj: typeof AbiEnum): boolean;
