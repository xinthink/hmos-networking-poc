export declare enum BitUpdateFlag {
    NONE = 0,
    FIRST = 1,
    SECOND = 2,
    THIRD = 4
}
/**
 * 通用工具函数
 */
export declare class BitUpdateFlagUtils {
    /**
     * 设置（可以一次设置多位）
     * @param {BitUpdateFlag} src
     * @param {BitUpdateFlag} flags
     * @returns {BitUpdateFlag}
     */
    static set(src: BitUpdateFlag, ...flags: BitUpdateFlag[]): BitUpdateFlag;
    /**
     * 清除（可以一次清除多位）
     * @param {BitUpdateFlag} src
     * @param {BitUpdateFlag} flags
     * @returns {BitUpdateFlag}
     */
    static clear(src: BitUpdateFlag, ...flags: BitUpdateFlag[]): BitUpdateFlag;
    /**
     *  取反（toggle）
     * @param {BitUpdateFlag} src
     * @param {BitUpdateFlag} flags
     * @returns {BitUpdateFlag}
     */
    static toggle(src: BitUpdateFlag, ...flags: BitUpdateFlag[]): BitUpdateFlag;
    /**
     * 判断是否全部包含（AND 检测）
     * @param {BitUpdateFlag} src
     * @param {BitUpdateFlag} flag
     * @returns {boolean}
     */
    static has(src: BitUpdateFlag, flag: BitUpdateFlag): boolean;
}
