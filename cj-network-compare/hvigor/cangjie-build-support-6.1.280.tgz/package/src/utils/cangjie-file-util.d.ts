import { OhosLogger } from '@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger';
import { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
/**
 * Clear Folder Contents
 * @param {string} filePath
 */
export declare function clearDir(filePath: string): void;
export declare function matchFiles(dir: string, regex: RegExp): string[];
export declare function traverseDir(currentDir: string, regex: RegExp, files: string[]): void;
export declare function createDir(fileDir: string): boolean;
export declare function deleteExtensionFiles(dir: string, extension: string): void;
export declare function buildLogRelatePath(): string;
export declare function cangjieSrcRelatePath(): string;
export declare function syscapApiConfigPath(): string;
export declare function onlyCangjieModule(moduleDir: string): boolean;
export declare function hasEtsModule(moduleDir: string): boolean;
export declare function hasCangjieModule(moduleDir: string): boolean;
export declare function hasArktsCangjieModule(moduleDir: string): boolean;
/**
 * Compare whether two paths are the same.
 * @param path1 First path
 * @param path2 Second path
 * @returns If path2 is a subpath of path1, true is returned. Otherwise, false is returned.
 */
export declare function areChildPath(path1: string, path2: string): boolean;
export declare function readTomlContent(tomlPath: string, logger: OhosLogger): any;
export declare function readTomlStringValue(tomlPath: string, keys: string[], logger: OhosLogger): string;
export declare function readPackageName(tomlPath: string, logger: OhosLogger): string;
export declare function readPackageNameDirect(tomlData: any): string;
export declare function validateCangjieEntry(rootPackage: string, srcEntry: string): boolean;
export declare function copyLibsCommon(libPath: string, destPath: string): Promise<void>;
export declare function readModuleConfigTomlName(targetService: TargetTaskService, logger: OhosLogger): string;
export declare function readModuleConfigToml(targetService: TargetTaskService): string;
export declare function readTomlSrcDir(tomlData: any): string;
export declare function readAsanEnabled(appJsonPath: string, logger: OhosLogger): boolean;
export declare function copyAllSubFilesWithDir(srcPath: string, destPath: string): Promise<void>;
export declare function copyAllSubFilesNoDir(srcPath: string, destPath: string): Promise<void>;
export declare function walkSync(dirPath: string): string[];
export declare function walkSyncWithFilter(dirPath: string, extendName: string, demandPkgs: string[]): string[];
export declare function linkFile(srcFile: string, destFile: string): Promise<void>;
export declare function copySpecifiedFiles(files: string[], srcPath: string, destPath: string): Promise<void>;
/**
 * 检查目录是否为空（无文件），如果是则删除
 * @param dirPath 目录路径
 * @returns 如果目录被删除返回 true，否则返回 false
 */
export declare function deleteIfNoFiles(dirPath: string): Promise<boolean>;
export declare function isCangjieHar(dirPath: string): boolean;
