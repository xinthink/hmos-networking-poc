/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */
import { OhosLogger } from '@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger';
/**
 * cjpm command
 *
 * @since 2025/10/10
 */
export declare class CjpmCommandBuilder {
    private commands;
    private readonly logger?;
    constructor(baseCommand: string, logger?: OhosLogger);
    buildCmd(): this;
    testCmd(noRun?: boolean): this;
    withOhosTestIfNeeded(isOhosTest: boolean): this;
    withCoverage(): this;
    withTarget(target: string): this;
    withParallelJobs(cpuNums: number): this;
    withTargetDir(targetDir: string): this;
    withBuildMode(isDebug: boolean): this;
    withCustomArgs(args: string[]): this;
    build(): string[];
}
