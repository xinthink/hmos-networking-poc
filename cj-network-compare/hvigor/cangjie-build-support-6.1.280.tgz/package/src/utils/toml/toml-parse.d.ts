import type { CustomTomlTypes } from './toml-types';
import { LocationEnum } from './toml-enum';
export interface CommentRecord {
    comment: string;
    location: LocationEnum;
}
export declare function parseToml(content: string, commentMap: Map<string, CommentRecord[]>): Record<string, CustomTomlTypes>;
