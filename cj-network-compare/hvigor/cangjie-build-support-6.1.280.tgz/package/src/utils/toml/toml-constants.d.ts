/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
export declare const DATE_TIME_REGEX: RegExp;
export declare const INT_REGEX: RegExp;
export declare const FLOAT_REGEX: RegExp;
export declare const LEADING_ZERO_REGEX: RegExp;
export declare const ESCAPE_REGEX: RegExp;
export declare const KEY_REGEX: RegExp;
export declare const LINE_SPLITTER_REGEX: RegExp;
export declare const KEY_PART_REGEX: RegExp;
export declare const DATE_HOURS_INDEX = 2;
export declare const DATE_MAX_HOURS = 23;
export declare const DATE_OFFSET_INDEX = 3;
export declare const DATE_END_INDEX = 10;
export declare const TIME_START_INDEX = 11;
export declare const TIME_END_INDEX = 23;
export declare const HOUR_MINUTES_SECONDS = 60;
export declare const MILL_SECONDS = 1000;
export declare const MINUTE_START_INDEX = 4;
export declare const MINUTE_END_INDEX = 6;
export declare const TWO_POS_OFFSET = 2;
export declare const LOWER_CHARACTER_LENGTH = 4;
export declare const UPPER_CHARACTER_LENGTH = 8;
export declare const ESCAPE_SYMBOL_MAP: {
    b: string;
    t: string;
    n: string;
    f: string;
    r: string;
    '"': string;
    '\\': string;
};
