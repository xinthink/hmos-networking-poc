/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
export declare const enum ObjType {
    DOT = 0,
    EXPLICIT = 1,
    ARRAY = 2,
    ARRAY_DOT = 3
}
export declare enum LocationEnum {
    BEFORE = 0,
    AFTER = 1
}
