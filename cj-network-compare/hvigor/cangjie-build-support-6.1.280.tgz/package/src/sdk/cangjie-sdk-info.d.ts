/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
export declare const componentMap: Map<string, any>;
export declare const sdkVersionMap: Map<number, string>;
/**
 * init sdk info
 * @param {TargetTaskService} taskService
 * @returns {Promise<void>}
 */
export declare function initSdkInfo(taskService: TargetTaskService): Promise<void>;
export declare function getSdkComponent(sdkPath: string, version: number): any;
export declare function getSdkKey(sdkPath: string, version: number): string;
export interface SdkComponent {
    location: string;
    componentApiVersion: number;
}
