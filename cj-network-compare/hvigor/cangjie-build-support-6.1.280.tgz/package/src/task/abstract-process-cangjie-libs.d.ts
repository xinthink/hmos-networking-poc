import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { BaseCangjieTask } from './base-cangjie-task';
import type { TaskDetails } from '@ohos/hvigor';
/**
 * process cangjie libs task
 *
 * @since 2024/5/6
 */
export declare abstract class AbstractProcessCangjieLibs extends BaseCangjieTask {
    private apclLogger;
    protected constructor(taskService: TargetTaskService, taskDetails: TaskDetails);
    protected doTaskAction(): Promise<void>;
    protected copyProcessCangjieLibs(libsPath: string, destPath: string, unTile: boolean): Promise<void>;
}
