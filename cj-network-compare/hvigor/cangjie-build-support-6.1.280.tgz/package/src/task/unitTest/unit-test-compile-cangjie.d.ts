/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { AbstractCompileCangjie } from '../abstract-compile-cangjie';
/**
 * compile cangjie task
 *
 * @since 2025/7/22
 */
export declare class UnitTestCompileCangjie extends AbstractCompileCangjie {
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
}
